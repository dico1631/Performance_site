package com.project.performance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerformanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
